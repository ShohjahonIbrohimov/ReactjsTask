import React from 'react'
import NormalLoginForm from '../../components/LoginForm'

const index = () => {
    return (
        <div className="custom_container">
            <NormalLoginForm />
        </div>
    )
}

export default index
